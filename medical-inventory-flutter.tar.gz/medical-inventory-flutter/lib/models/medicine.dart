class Medicine {
  final int id;
  final String name;
  final String company;
  final int stock;
  final double price;
  final String expiryDate;
  final double commissionPct;
  final String scheme;

  Medicine({
    required this.id,
    required this.name,
    required this.company,
    required this.stock,
    required this.price,
    required this.expiryDate,
    required this.commissionPct,
    required this.scheme,
  });

  factory Medicine.fromJson(Map<String, dynamic> json) {
    return Medicine(
      id: json['id'],
      name: json['name'],
      company: json['company'],
      stock: json['stock'],
      price: (json['price'] as num).toDouble(),
      expiryDate: json['expiry_date'],
      commissionPct: (json['commission_pct'] as num).toDouble(),
      scheme: json['scheme'] ?? 'Standard Rates',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'company': company,
      'stock': stock,
      'price': price,
      'expiry_date': expiryDate,
      'commission_pct': commissionPct,
      'scheme': scheme,
    };
  }
}
