import 'package:flutter/material.dart';
import '../models/user.dart';
import '../models/medicine.dart';
import '../models/order.dart';
import '../services/api_service.dart';

class DoctorDashboard extends StatefulWidget {
  final User user;
  final Function() onLogout;

  const DoctorDashboard({
    Key? key,
    required this.user,
    required this.onLogout,
  }) : super(key: key);

  @override
  State<DoctorDashboard> createState() => _DoctorDashboardState();
}

class _DoctorDashboardState extends State<DoctorDashboard> {
  late Future<List<Medicine>> _medicinesFuture;
  late Future<List<Order>> _ordersFuture;
  String? _message;
  Map<int, int> _quantities = {};

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    _medicinesFuture = ApiService.getMedicines().then(
      (data) => (data as List).map((m) => Medicine.fromJson(m)).toList(),
    );
    _ordersFuture = ApiService.getOrders().then(
      (data) => (data as List).map((o) => Order.fromJson(o)).toList(),
    );
  }

  void _placeOrder(Medicine medicine) async {
    final qty = _quantities[medicine.id] ?? 0;
    if (qty <= 0) {
      _showMessage('Please enter a valid quantity', Colors.red);
      return;
    }

    try {
      await ApiService.placeOrder(medicine.id, qty);
      _showMessage('✅ Order placed for ${medicine.name}!', Colors.green);
      _quantities[medicine.id] = 0;
      _loadData();
    } catch (e) {
      _showMessage(e.toString().replaceAll('Exception: ', ''), Colors.red);
    }
  }

  void _showMessage(String msg, Color color) {
    setState(() => _message = msg);
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) setState(() => _message = null);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF667EEA),
        title: Text('Dr. ${widget.user.username}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: widget.onLogout,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_message != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _message!.startsWith('✅') ? Colors.green.shade100 : Colors.red.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(_message!),
              ),
            if (_message != null) const SizedBox(height: 16),
            const Text(
              'Available Medicines',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            FutureBuilder<List<Medicine>>(
              future: _medicinesFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }
                final medicines = snapshot.data ?? [];
                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: medicines.length,
                  itemBuilder: (context, index) {
                    final med = medicines[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        med.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                      Text(med.company, style: const TextStyle(color: Colors.grey)),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.blue.shade100,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text('₹${med.price}'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Stock: ${med.stock > 0 ? '${med.stock} units' : 'Out of Stock'}',
                              style: TextStyle(
                                color: med.stock > 0 ? Colors.green : Colors.red,
                              ),
                            ),
                            Text('Scheme: ${med.scheme}', style: const TextStyle(fontSize: 12)),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: TextField(
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      hintText: 'Qty',
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    ),
                                    onChanged: (value) {
                                      _quantities[med.id] = int.tryParse(value) ?? 0;
                                    },
                                  ),
                                ),
                                const SizedBox(width: 8),
                                ElevatedButton(
                                  onPressed: med.stock > 0 ? () => _placeOrder(med) : null,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.green,
                                  ),
                                  child: const Text('Order', style: TextStyle(color: Colors.white)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 24),
            const Text(
              'My Orders',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            FutureBuilder<List<Order>>(
              future: _ordersFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }
                final orders = snapshot.data ?? [];
                if (orders.isEmpty) {
                  return const Text('No orders yet');
                }
                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: orders.length,
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  order.medName,
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: order.status == 'Delivered'
                                        ? Colors.green.shade100
                                        : order.status == 'Cancelled'
                                            ? Colors.red.shade100
                                            : Colors.orange.shade100,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(order.status, style: const TextStyle(fontSize: 12)),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text('Qty: ${order.qty} | Total: ₹${order.totalBill}'),
                            Text(order.orderDate, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
